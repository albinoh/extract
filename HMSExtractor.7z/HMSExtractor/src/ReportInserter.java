import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.configuration2.Configuration;

public class ReportInserter {
	
	private static ReportInserter mInstance;
	
	
	private Connection mConnection;
	private PreparedStatement mPreparedStmtRepDef;
	private Configuration gConfig;
	
	private ReportInserter(Connection iConn, Configuration iConfig) throws SQLException{
		gConfig = iConfig;
		String lReportTable = gConfig.getString("table.report");
		mConnection = iConn;
		mPreparedStmtRepDef = iConn.prepareStatement("insert into "+ lReportTable +" (REP_GUID, REP_LOC, REP_NAME, REP_DESC, "
				+ "REP_OWNER_GUID, REP_OWNER_NAME, REP_CREATE_DATE, REP_MODIF_DATE, PROJ_GUID) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?)");

	}
	
	public static ReportInserter getReportInserter(Connection iConn, Configuration iConfig) throws SQLException{
		if(mInstance == null){
			mInstance = new ReportInserter(iConn, iConfig);
		}
		return mInstance;
	}
	
	public void insertReportInfo(String iRepGUID, String iRepLoc, String iRepName, String iRepDesc, String iRepOwnerGUID, String iRepOwnerName, 
			String iRepCreation, String iRepModification, String iProjectGUID ) throws SQLException{
		Boolean lDoInserts = Boolean.parseBoolean(gConfig.getString("config.doinserts"));
		
		if(lDoInserts) {
			mPreparedStmtRepDef.setString (1, iRepGUID);
			mPreparedStmtRepDef.setString (2, iRepLoc);
			mPreparedStmtRepDef.setString (3, iRepName);
			mPreparedStmtRepDef.setString (4, iRepDesc);
			mPreparedStmtRepDef.setString (5, iRepOwnerGUID);
			mPreparedStmtRepDef.setString (6, iRepOwnerName);
			mPreparedStmtRepDef.setString (7, iRepCreation);
			mPreparedStmtRepDef.setString (8, iRepModification);
			mPreparedStmtRepDef.setString (9, iProjectGUID);
			  // execute the preparedstatement
			mPreparedStmtRepDef.execute();
		}
		
	}
	
}
