import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.FileBasedConfiguration;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.ex.ConfigurationException;

public class TableReducer {
	
	private static Configuration gConfig;
	private static Connection gTeraConn;
	
	
	public static void generateTableSets() {
		
		String lTableQuery = gConfig.getString("query.tables");

		
		
		try {
				Statement st = gTeraConn.createStatement();
				ResultSet rec = st.executeQuery(lTableQuery);
				String lRetReportID = "";
				while (rec.next()) {
					String[] lArray = new String[6];
					System.out.println(rec.getString(1));
					System.out.println(rec.getString(2));
					System.out.println(rec.getString(3));
					System.out.println(rec.getString(4));
					System.out.println(rec.getString(5));
					System.out.println(rec.getString(6));
					lArray[0] = rec.getString(1);
					lArray[1] = rec.getString(2);
					lArray[2] = rec.getString(3);
					lArray[3] = rec.getString(4);
					lArray[4] = rec.getString(5);
					lArray[5] = rec.getString(6);
					//gTableMap.put(lArray[5], lArray);
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void main(String[] args) throws ConfigurationException, ClassNotFoundException, SQLException{
		//mUser = args[0];
		//mPassword = args[1];
		//mProjectName = args[2];
		
		Parameters params = new Parameters();
		FileBasedConfigurationBuilder<FileBasedConfiguration> builder =
		    new FileBasedConfigurationBuilder<FileBasedConfiguration>(PropertiesConfiguration.class)
		    .configure(params.properties()
		        .setFileName("application.properties"));
		gConfig = builder.getConfiguration();
		
		String connTeraString =gConfig.getString("jdbc.teraconnection");
		String lTeraUser = gConfig.getString("jdbc.terauser");
		String lTeraPwd = gConfig.getString("jdbc.terapwd");
		
		
		Class.forName("com.teradata.jdbc.TeraDriver");
		gTeraConn = DriverManager.getConnection(connTeraString, lTeraUser, lTeraPwd);
		
		generateTableSets();
		System.exit(0);
	}
}
