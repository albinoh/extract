
public class PromptInserter {

}
