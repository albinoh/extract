import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.configuration2.Configuration;

public class MetricInserter {
	
	private static MetricInserter mInstance;
	
	
	private Connection mConnection;
	private PreparedStatement mPreparedStmtMetDef;
	private PreparedStatement mPreparedStmtMetRel;
	private Configuration gConfig;
	
	private MetricInserter(Connection iConn, Configuration iConfig) throws SQLException{
		gConfig = iConfig;
		String lMetricTable = gConfig.getString("table.metric");
		String lMetricRelateTable = gConfig.getString("table.metricrelate");
		
		
		mConnection = iConn;
		mPreparedStmtMetDef = iConn.prepareStatement("insert into "+lMetricTable+" (MET_GUID, MET_DEF, MET_FILT, MET_LEVEL, "
				+ "MET_TRANS, MET_TYPE, PROJ_GUID) values (?, ?, ?, ?, ?, ?, ?)");
		mPreparedStmtMetRel = iConn.prepareStatement("insert into "+lMetricRelateTable+" (REP_GUID, MET_GUID, "
				+ "PROJ_ID, PROJ_GUID, TEMPLATE_FLAG) values (?, ?, ?, ?, ?)");

	}
	
	public static MetricInserter getMetricInserter(Connection iConn, Configuration iConfig) throws SQLException{
		if(mInstance == null){
			mInstance = new MetricInserter(iConn, iConfig);
		}
		
		return mInstance;
	}
	
	public void insertMetricInfo(Boolean onlyRelate, String iMetricGUID, String iMetricFormula, String iMetricFilter, 
			String iMetricLevel, String iMetricTrans, String iMetricType, 
			String iReportGUID, String iProjectID, String iProjectGUID, Short isPromptSource ) throws SQLException{
		
		Boolean lDoInserts = Boolean.parseBoolean(gConfig.getString("config.dometinserts"));
		Boolean lDoRelInserts = Boolean.parseBoolean(gConfig.getString("config.dometrelinserts"));
		
		if(lDoInserts) {
			if(iMetricType.equals("Derived") && !onlyRelate) {
				mPreparedStmtMetDef.setString (1, iMetricGUID);
				mPreparedStmtMetDef.setString (2, iMetricFormula);
				mPreparedStmtMetDef.setString (3, iMetricFilter);
				mPreparedStmtMetDef.setString (4, iMetricLevel);
				mPreparedStmtMetDef.setString (5, iMetricTrans);
				mPreparedStmtMetDef.setString (6, iMetricType);
				mPreparedStmtMetDef.setString (7, iProjectGUID);
				  // execute the preparedstatement
				mPreparedStmtMetDef.execute();
			}
		}
		
		if(lDoRelInserts) {
			mPreparedStmtMetRel.setString (1, iReportGUID);
			mPreparedStmtMetRel.setString (2, iMetricGUID);
			mPreparedStmtMetRel.setString (3, iProjectID);
			mPreparedStmtMetRel.setString (4, iProjectGUID);
			mPreparedStmtMetRel.setShort(5, isPromptSource);
			mPreparedStmtMetRel.execute();
		}
		
		
	}
	
}
