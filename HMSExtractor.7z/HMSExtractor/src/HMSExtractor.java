import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Properties;

import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.FileBasedConfiguration;
import org.apache.commons.configuration2.PropertiesConfiguration;
import org.apache.commons.configuration2.builder.FileBasedConfigurationBuilder;
import org.apache.commons.configuration2.builder.fluent.Configurations;
import org.apache.commons.configuration2.builder.fluent.Parameters;
import org.apache.commons.configuration2.ex.ConfigurationException;

import com.microstrategy.web.app.beans.AppBeanFactory;
import com.microstrategy.web.app.beans.ReportFrameBean;
import com.microstrategy.web.beans.BeanFactory;
import com.microstrategy.web.beans.ReportBean;
import com.microstrategy.web.beans.ViewBean;
import com.microstrategy.web.beans.WebBeanException;
import com.microstrategy.web.beans.WebBeanFactory;
import com.microstrategy.web.beans.WebException;
import com.microstrategy.web.objects.EnumWebLimitSummaryFlags;
import com.microstrategy.web.objects.EnumWebPromptType;
import com.microstrategy.web.objects.EnumWebReportExecutionModes;
import com.microstrategy.web.objects.EnumWebReportSourceType;
import com.microstrategy.web.objects.SimpleList;
import com.microstrategy.web.objects.WebAttribute;
import com.microstrategy.web.objects.WebConstantPrompt;
import com.microstrategy.web.objects.WebDefaultDisplaySettings;
import com.microstrategy.web.objects.WebDimension;
import com.microstrategy.web.objects.WebDisplayHelper;
import com.microstrategy.web.objects.WebElementSource;
import com.microstrategy.web.objects.WebElements;
import com.microstrategy.web.objects.WebElementsPrompt;
import com.microstrategy.web.objects.WebElementsPromptAnswer;
import com.microstrategy.web.objects.WebExpression;
import com.microstrategy.web.objects.WebExpressionPrompt;
import com.microstrategy.web.objects.WebFilter;
import com.microstrategy.web.objects.WebFolder;
import com.microstrategy.web.objects.WebIServerSession;
import com.microstrategy.web.objects.WebMetric;
import com.microstrategy.web.objects.WebNode;
import com.microstrategy.web.objects.WebObjectInfo;
import com.microstrategy.web.objects.WebObjectSource;
import com.microstrategy.web.objects.WebObjectsException;
import com.microstrategy.web.objects.WebObjectsFactory;
import com.microstrategy.web.objects.WebObjectsPrompt;
import com.microstrategy.web.objects.WebPrompt;
import com.microstrategy.web.objects.WebPromptInstances;
import com.microstrategy.web.objects.WebPrompts;
import com.microstrategy.web.objects.WebReportExecutionSettings;
import com.microstrategy.web.objects.WebPromptableNode;
import com.microstrategy.web.objects.WebReportInstance;
import com.microstrategy.web.objects.WebReportManipulation;
import com.microstrategy.web.objects.WebReportSource;
import com.microstrategy.web.objects.WebReportValidationException;
import com.microstrategy.web.objects.WebShortcutNode;
import com.microstrategy.web.objects.WebTemplate;
import com.microstrategy.web.objects.WebTemplateMetric;
import com.microstrategy.web.objects.WebTemplateMetrics;
import com.microstrategy.web.objects.WebTemplateUnit;
import com.microstrategy.web.objects.WebViewInstance;
import com.microstrategy.web.objects.WebWorkingSet;
import com.microstrategy.webapi.EnumDSSXMLAuthModes;
import com.microstrategy.webapi.EnumDSSXMLExecutionFlags;
import com.microstrategy.webapi.EnumDSSXMLExpressionType;
import com.microstrategy.webapi.EnumDSSXMLFolderNames;
import com.microstrategy.webapi.EnumDSSXMLFunction;
import com.microstrategy.webapi.EnumDSSXMLObjectFlags;
import com.microstrategy.webapi.EnumDSSXMLObjectSubTypes;
import com.microstrategy.webapi.EnumDSSXMLObjectTypes;
import com.microstrategy.webapi.EnumDSSXMLReportSaveAsFlags;
import com.microstrategy.webapi.EnumDSSXMLResultFlags;

import com.microsoft.sqlserver.jdbc.SQLServerDriver;

public class HMSExtractor {
	
	private static Configuration gConfig;
	
	private static WebObjectsFactory gFactory = null;
	private static WebIServerSession gServerSession = null;
	private static WebObjectSource gObjSource = null;
	
	private static Connection gConn;
	private static Connection gTeraConn;
	private static MetricInserter gMetInserter;
	private static ReportInserter gReportInserter;
	private static AttributeInserter gAttributeInserter;
	private static ErrorInserter gErrorInserter;
	private static ReportTableRelInserter gReportTableRelInserter;
	
	private static HashSet<String> gAttributeSet = new HashSet<String>();
	private static HashSet<String> gMetricSet = new HashSet<String>();
	
	private static HashMap<String, String[]> gTableMap = new HashMap<String, String[]>();
	
	private static String mUser = "administrator";
	private static String mPassword = "";
	private static String mProjectName = "";
	private static String mServer = "";
	
	public static WebIServerSession getSession(){
		

		
		mUser =gConfig.getString("mstr.user");
		mPassword =gConfig.getString("mstr.pwd");
		mProjectName =gConfig.getString("mstr.project");
		mServer=gConfig.getString("mstr.server");
		
		gFactory = WebObjectsFactory.getInstance();
		gObjSource = gFactory.getObjectSource();
		gServerSession = gFactory.getIServerSession();
		
		// Set up session properties
		gServerSession.setServerName(mServer); // Should be replaced with the name of an Intelligence Server
		gServerSession.setServerPort(0);
		gServerSession.setProjectName(mProjectName);
		gServerSession.setLogin(mUser); // User ID
		gServerSession.setAuthMode(EnumDSSXMLAuthModes.DssXmlAuthStandard);
		gServerSession.setPassword(mPassword); // Password
		
		try {
			System.out.println("nSession created with ID: "+ gServerSession.getSessionID());
		} catch (WebObjectsException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Session State: "+ gServerSession.saveState(0));
		// Return session
		return gServerSession;
	}
	
	
	public static void createInserters() {
		
		String connString =gConfig.getString("jdbc.connection");
		String lUser = gConfig.getString("jdbc.user");
		String lPwd = gConfig.getString("jdbc.pwd");
		String lReportQuery = gConfig.getString("query.report");
		String lDBType = gConfig.getString("jdbc.dbtype");
		
		String connTeraString =gConfig.getString("jdbc.teraconnection");
		String lTeraUser = gConfig.getString("jdbc.terauser");
		String lTeraPwd = gConfig.getString("jdbc.terapwd");
		
		try {
				Class.forName("com.teradata.jdbc.TeraDriver");
				if(lDBType.equals("oracle")) {
					Class.forName("oracle.jdbc.driver.OracleDriver");
				} else if (lDBType.equals("sqlserver")) {
					Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				}
				gConn = DriverManager.getConnection(connString, lUser, lPwd);
				gTeraConn = DriverManager.getConnection(connTeraString, lTeraUser, lTeraPwd);
				gMetInserter = MetricInserter.getMetricInserter(gTeraConn, gConfig);
				gReportInserter = ReportInserter.getReportInserter(gConn, gConfig);
				gAttributeInserter = AttributeInserter.getAttributeInserter(gConn, gConfig);
				gReportTableRelInserter = ReportTableRelInserter.getReportTableRelInserter(gTeraConn, gConfig);
				gErrorInserter = ErrorInserter.getErrorInserter(gTeraConn, gConfig);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static void populateTableInfo() {
		
		String lTableQuery = gConfig.getString("query.tables");

		try {
				Statement st = gConn.createStatement();
				ResultSet rec = st.executeQuery(lTableQuery);
				String lRetReportID = "";
				while (rec.next()) {
					String[] lArray = new String[6];
					System.out.println(rec.getString(1));
					System.out.println(rec.getString(2));
					System.out.println(rec.getString(3));
					System.out.println(rec.getString(4));
					System.out.println(rec.getString(5));
					System.out.println(rec.getString(6));
					lArray[0] = rec.getString(1);
					lArray[1] = rec.getString(2);
					lArray[2] = rec.getString(3);
					lArray[3] = rec.getString(4);
					lArray[4] = rec.getString(5);
					lArray[5] = rec.getString(6);
					gTableMap.put(lArray[5], lArray);
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public static void populateDerivedMetricData() {
		
		WebReportSource rSource = gFactory.getReportSource();
		
		//Just execute prompts no SQL 
 //rSource.setExecutionFlags(EnumDSSXMLExecutionFlags.DssXmlExecutionNoAction);
		//rSource.setExecutionFlags(EnumDSSXMLExecutionFlags.DssXmlExecutionResolve);
		//rSource.setExecutionFlags(EnumDSSXMLExecutionFlags.);

		//These force SQL generation
		//rSource.setResultFlags(EnumDSSXMLResultFlags.DssXmlResultXmlSQL);
		rSource.setExecutionFlags(EnumDSSXMLExecutionFlags.DssXmlExecutionGenerateSQL);
		//rSource.setResultFlags(EnumDSSXMLResultFlags.DssXmlResultWorkingSet | EnumDSSXMLResultFlags.DssXmlResultViewReport | EnumDSSXMLResultFlags.DssXmlResultStatusOnlyIfNotReady);
		rSource.setResultFlags(EnumDSSXMLResultFlags.DssXmlResultXmlSQL| EnumDSSXMLResultFlags.DssXmlResultWorkingSet | EnumDSSXMLResultFlags.DssXmlResultViewReport | EnumDSSXMLResultFlags.DssXmlResultFilter |EnumDSSXMLResultFlags.DssXmlResultDtlsFilterExpr);
		//rSource.setResultFlags(EnumDSSXMLResultFlags.DssXmlResultViewReport);

		String connString =gConfig.getString("jdbc.connection");
		String lUser = gConfig.getString("jdbc.user");
		String lPwd = gConfig.getString("jdbc.pwd");
		String lReportQuery = gConfig.getString("query.report");
		String lDBType = gConfig.getString("jdbc.dbtype");
		
		try {
				
				int rCount =0;
				Statement st = gConn.createStatement();
				ResultSet rec = st.executeQuery(lReportQuery);
				String lRetReportID = "";
				String lRetReportGUID = "";
				String lRetReportName = "";
				String lRetProjID = "";
				String lRetProjGUID = "";
				while (rec.next()) {
					try{
						System.out.println(rec.getString(1));
						System.out.println(++rCount);
						lRetReportID = rec.getString(1);
						lRetReportGUID = rec.getString(2);
						lRetReportName = rec.getString(3);
						lRetProjID = rec.getString(5);
						lRetProjGUID = rec.getString(6);
						
						//lRetReportID = "11105";
						//lRetReportGUID = "B144351611E6C2FA000000802FA725F0";
						
						
						WebReportInstance wrpInstance = rSource.getNewInstance();
						
						WebObjectInfo oInfoReport = gObjSource.getObject(lRetReportGUID, EnumDSSXMLObjectTypes.DssXmlTypeReportDefinition, true);
						//WebObjectInfo lTPromptRetrieve = gObjSource.getObject("41530D4348CDB4745B0B8EB2799F4865", EnumDSSXMLObjectTypes.DssXmlTypePrompt, true);
						//System.out.println("SubType: "+oInfoReport.getSubType());
						//System.out.println("ExtendedType: "+oInfoReport.getExtendedType());
						//System.out.println("Flags: "+oInfoReport.getFlags());
						//System.out.println("State: "+oInfoReport.getState());

						if (oInfoReport.getSubType() == 776) {
							AppBeanFactory abf = AppBeanFactory.getInstance();

							ReportFrameBean rfb = (ReportFrameBean) abf.newBean("ReportFrameBean");
							rfb.setName("rfb");

							ReportBean rb = (ReportBean) BeanFactory.getInstance().newBean("ReportBean");;
							rb.setParent(rfb);
							rb.setSessionInfo(gServerSession);
							rb.setName("rb");
							
							WebReportSource wrs = gFactory.getReportSource();
							
							WebReportExecutionSettings settings = wrs.newExecutionSettings();
							settings.setSource(lRetReportGUID, EnumWebReportSourceType.WebReportSourceTypeCube);
							
							WebReportInstance cubeWri = wrs.getNewInstance(settings);
							rb.setReportInstance(cubeWri);
							rb.collectData();

							WebObjectSource wos = gFactory.getObjectSource();

							ViewBean vb = rb.getViewBean();
							WebViewInstance wvi = vb.getViewInstance();
							WebWorkingSet workSet = wvi.getWorkingSet();
							WebFolder lResults = workSet.getWorkingSetObjects();

							//WebObjectInfo row = workSetFolder.get(1);
							gReportInserter.insertReportInfo(oInfoReport.getID(), buildPath(oInfoReport.getAncestors()), 
									oInfoReport.getName(), oInfoReport.getDescription(), oInfoReport.getOwner().getID(),
									oInfoReport.getOwner().getName(), oInfoReport.getCreationTime(), oInfoReport.getModificationTime(),
									gServerSession.getProjectID());
							
							for(int k=0; k<lResults.size(); k++){
								switch(lResults.get(k).getType()){
									case 4:
										WebMetric lMetric = (WebMetric) lResults.get(k);
										processMetric(lMetric, oInfoReport.getID(), lRetProjID, (short)0);
									break;
									case 12:
										WebAttribute lAttribute = (WebAttribute) gObjSource.getObject(lResults.get(k).getID(), EnumDSSXMLObjectTypes.DssXmlTypeAttribute, true);
										processAttribute(lAttribute, oInfoReport.getID(), (short)0);

									break;
									case 10:
										WebPrompt lPrompt = (WebPrompt) gObjSource.getObject(lResults.get(k).getID(), EnumDSSXMLObjectTypes.DssXmlTypePrompt, true);
										processPromptObjects(lPrompt, oInfoReport.getID());
										break;
									default :
										int lMissingType = lResults.get(k).getType();
										System.out.println(lMissingType);
									break;
								}
							}
							
							
						} else if(oInfoReport.getSubType() != 780 && oInfoReport.getSubType() != 777 && oInfoReport.getSubType() != 775){
							
							
						
							String lReportId = "";
							

							WebReportInstance rInstance = rSource.getNewInstance(lRetReportGUID);
							
							
						
							rInstance.setExecutionMode(1);
							rInstance.setMaxWait(-1);				
							rInstance.setAsync(false);
							
							
							WebPrompts prompts = rInstance.getPrompts();
							int maxObjects = 25;
							if(prompts.size()>0){
								for(int i = 0; i<prompts.size(); i++){
									WebPrompt lCurrentPrompt = prompts.get(i);
									switch (lCurrentPrompt.getPromptType()) {
										case EnumWebPromptType.WebPromptTypeObjects:
											WebObjectsPrompt objPrompt = null;
											objPrompt = (WebObjectsPrompt) lCurrentPrompt;
											//if (!objPrompt.hasOriginalAnswer()) {
												if (objPrompt.hasDefaultAnswer()) {
													objPrompt.setAnswer(objPrompt.getDefaultAnswer());
												}
												else if (objPrompt.hasPreviousAnswer()) {
													objPrompt.setAnswer(objPrompt.getPreviousAnswer());
												}  else{
													answerObjectPrompt(objPrompt);
												}
											//}
											//if (objPrompt.getSearchRestriction() != null) {
											//	objPrompt.getSearchRestriction().setBlockBegin(1);
											//	objPrompt.getSearchRestriction().setBlockCount(maxObjects);	
											//}		
											break;
										case EnumWebPromptType.WebPromptTypeElements:
											WebElementsPrompt elePrompt = null;
											elePrompt = (WebElementsPrompt) lCurrentPrompt;
											if (elePrompt.hasDefaultAnswer()) {
												elePrompt.setAnswer(elePrompt.getDefaultAnswer());
											}
											else if (elePrompt.hasPreviousAnswer()) {
												elePrompt.setAnswer(elePrompt.getPreviousAnswer());
											} else if (elePrompt.hasAnswer()) {
												
											}else{
												answerElementPrompt(elePrompt);
											}
											break;
										case EnumWebPromptType.WebPromptTypeConstant:
											WebConstantPrompt wcp = (WebConstantPrompt) lCurrentPrompt;
											if (wcp.hasDefaultAnswer()) {
												wcp.setAnswer(wcp.getDefaultAnswer());
											}
											else if (wcp.hasPreviousAnswer()) {
												wcp.setAnswer(wcp.getPreviousAnswer());
											} else{
												answerConstantPrompt(wcp);
											}
											break;
										case EnumWebPromptType.WebPromptTypeExpression:
											WebExpressionPrompt wep = (WebExpressionPrompt) lCurrentPrompt;
											if (wep.hasDefaultAnswer()) {
												wep.setAnswer(wep.getDefaultAnswer());
											}
											else if (wep.hasPreviousAnswer()) {
												wep.setAnswer(wep.getPreviousAnswer());
											} else{
												answerExpressionPrompt(wep);
											}
											break;
									}
								}
								prompts.answerPrompts();
								WebPrompts prompts2 = rInstance.getPrompts();
							}
							
							
							String lSql = rInstance.getResults().getSQL();
							
							if(!lSql.contentEquals("")) {
								
								SQLTableParser parse = new SQLTableParser(lSql);
								Collection<String> lTables = parse.tables();
								System.out.println(lTables.toString());
								for(String lTable: lTables) {
									String[] lTabProps = null;
									if (lTable.contains(".")) {
										String[] lTabArr = lTable.split("\\.");
										if(lTabArr.length >1){
											lTabProps = gTableMap.get(lTable.split("\\.")[1]);
										}
									}
									if(lTabProps == null) {
										
									}else {
										//String iTabID, String iTabGUID, String iTabName, 
										//String iRepID, String iRepGUID, String iRepName, 
										//String iRepoGUID, String iProjID, String iProjGUID
										try {
											gReportTableRelInserter.insertReportTableRelInfo(lTabProps[0], lTabProps[1], lTabProps[5],
													lRetReportID, lRetReportGUID, lRetReportName, 
													lTabProps[2], lRetProjID, lTabProps[3]);
										} catch (SQLException e) {

												// TODO Auto-generated catch block
												e.printStackTrace();
										}
									}
									
								}
								
							}
							
							
							//objPrompt.getSuggestedAnswers().				 
							//int status = rInstance.pollStatus();
							
							//System.out.println("Template: "+rInstance.getTemplate());
							//rInstance.getResults();
							//System.out.println("XDA Type: "+rInstance.getXdaType());
							//WebReportManipulation manip= rInstance.getReportManipulator();
							if(rInstance.getTemplate() != null){
								
								
								
								gReportInserter.insertReportInfo(oInfoReport.getID(), buildPath(oInfoReport.getAncestors()), 
										oInfoReport.getName(), oInfoReport.getDescription(), oInfoReport.getOwner().getID(),
										oInfoReport.getOwner().getName(), oInfoReport.getCreationTime(), oInfoReport.getModificationTime(),
										gServerSession.getProjectID());
								WebFolder lResults = rInstance.getWorkingSet().getWorkingSetObjects();
								WebFilter lFilter = rInstance.getWorkingSet().getFilter();
								

								//Mark relationships and template objects
								for(int k=0; k<lResults.size(); k++){
									switch(lResults.get(k).getType()){
										case 4:
											WebMetric lMetric = (WebMetric) lResults.get(k);
											processMetric(lMetric, oInfoReport.getID(), lRetProjID, (short)0);
										break;
										case 12:
											WebAttribute lAttribute = (WebAttribute) gObjSource.getObject(lResults.get(k).getID(), EnumDSSXMLObjectTypes.DssXmlTypeAttribute, true);
											processAttribute(lAttribute, oInfoReport.getID(), (short)0);

										break;
										case 10:
											WebPrompt lPrompt = (WebPrompt) gObjSource.getObject(lResults.get(k).getID(), EnumDSSXMLObjectTypes.DssXmlTypePrompt, true);
											processPromptObjects(lPrompt, oInfoReport.getID());
											break;
										default :
											int lMissingType = lResults.get(k).getType();
											System.out.println(lMissingType);
										break;
									}
								}
								
								//for(int w=0; w< )
								
								
								/*
								WebTemplate template = rInstance.getTemplate();
								WebTemplateMetrics wtms = template.getTemplateMetrics();
								for(int j=0; j< wtms.size(); j++){
									WebTemplateMetric wtm = wtms.get(j);
									if(wtm.isDerived()){
										System.out.println("Metric: "+wtm.getFormula());
										System.out.println("Metric ID: "+wtm.getMetric().getID());
										

									}
								}
								*/
								//System.out.println("SQL: "+rInstance.getResults().getSQL());
								//WebTemplateMetric wtm = wtms.get(0);
							}
						
						}
						
					    	
					 } catch (WebObjectsException | WebBeanException e) {
						// TODO Auto-generated catch block
						gErrorInserter.insertErrorInfo(lRetReportGUID, e.getMessage());
						e.printStackTrace();
					 }
				}
				rec.close();
				st.close();
		} catch (SQLException e) {

			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	private static void processMetric(WebMetric iMetric, String iReportGUID, String iProjectID, Short isPromptSource) throws WebObjectsException, IllegalArgumentException, SQLException {
		Boolean lOnlyRelate = false;
		if(gMetricSet.contains(iMetric.getID())) {
			lOnlyRelate = true;
		}
		if(iMetric.getState() == 36991){
			gMetInserter.insertMetricInfo(lOnlyRelate, iMetric.getID(), iMetric.getFormula(), 
					"", "", "", "Derived", iReportGUID, iProjectID, gServerSession.getProjectID(), isPromptSource);

		}else {
			gMetInserter.insertMetricInfo(lOnlyRelate, iMetric.getID(), iMetric.getFormula(), 
					"", "", "", "Normal", iReportGUID, iProjectID, gServerSession.getProjectID(), isPromptSource);
		}
		gMetricSet.add(iMetric.getID());

	}
	
	private static void processAttribute(WebAttribute iAttribute, String iReportGUID, Short isPromptSource) throws WebObjectsException, IllegalArgumentException, SQLException {	
		Boolean lOnlyRelate = false;
		if(gAttributeSet.contains(iAttribute.getID())) {
			lOnlyRelate = true;
		}
		
		gAttributeInserter.insertAttributeInfo(lOnlyRelate, iAttribute.getID(), iAttribute.getName(), iAttribute.getOwner().getID(), 
				iAttribute.getOwner().getName(), iAttribute.getCreationTime(), iAttribute.getModificationTime(),
				iReportGUID, gServerSession.getProjectID(), isPromptSource);
		gAttributeSet.add(iAttribute.getID());
	
	}
	
	private static void processPromptObjects(WebPrompt iPrompt, String iReportGUID) throws WebObjectsException, IllegalArgumentException, SQLException {
		PromptAnswersAnalyser lPAnalyser = PromptAnswersAnalyser.getPromptAnswersAnalyser(gConn, gConfig);
		/*
		switch (iPrompt.getPromptType()) {
			case EnumWebPromptType.WebPromptTypeObjects:	
				WebObjectsPrompt objPrompt = null;
				objPrompt = (WebObjectsPrompt) iPrompt;
				WebFolder lAnswers = objPrompt.getSuggestedAnswers();
				if(lAnswers != null) {
					for(int i =0; i<lAnswers.size();i++) {
						switch(lAnswers.get(i).getType()) {
							case 4:
								WebMetric lMetric = (WebMetric) lAnswers.get(i);
								processMetric(lMetric, iReportGUID, (short)1);
							break;
							case 12:
								WebAttribute lAttribute = (WebAttribute) gObjSource.getObject(lAnswers.get(i).getID(), EnumDSSXMLObjectTypes.DssXmlTypeAttribute, true);
								processAttribute(lAttribute, iReportGUID, (short)1);
							break;
							case 1:
								System.out.println("Prompt with object type "+lAnswers.get(i).getType()+" not processed");
							break;
							default:
								System.out.println("Prompt with object type "+lAnswers.get(i).getType()+" not processed");
							break;
						}
					}
					break;
				}else {
					gErrorInserter.insertErrorInfo(iReportGUID, "Prompt issue");
				}
		}
		*/
		lPAnalyser.processPromptAns(iReportGUID, iPrompt.getID(), "");
	}
	
	
	private static void answerExpressionPrompt(WebExpressionPrompt prompt) throws WebObjectsException, IllegalArgumentException {
			WebExpression exp = prompt.getAnswer();
			if (prompt.getOrigin().getDisplayUnitType() == 12) {
				exp.populate("["+prompt.getOrigin().getDisplayName()+"]@ID=1");
			} else if (prompt.getOrigin().getChildUnits().get(0).getDisplayUnitType() == 14) {
				WebDimension lDim = (WebDimension)prompt.getOrigin().getChildUnits().get(0);
				lDim.populate();
				exp.populate("["+lDim.get(1).getDisplayName()+"]@ID=1");
			}else {
				exp.populate("["+prompt.getOrigin().getChildUnits().get(1).getDisplayName()+"]@ID=1");
			}
			
			prompt.setAnswer(exp);
	}
	
	private static void answerConstantPrompt(WebConstantPrompt prompt) throws WebObjectsException, IllegalArgumentException {
		//System.out.println("\nMethod Call: answerConstantPrompt");
			
			prompt.setAnswer("0");
	}
	
	private static void answerObjectPrompt(WebObjectsPrompt prompt) throws WebObjectsException, IllegalArgumentException {
		//System.out.println("\nMethod Call: answerObjectPrompt");
		
		WebFolder defaultWebFolder = prompt.getAnswer();
		defaultWebFolder.clear();
		WebFolder lAnswers = prompt.getSuggestedAnswers();
		if(lAnswers != null){
			WebObjectInfo lOneAnswer = lAnswers.get(0);		
			prompt.getAnswer().add(lOneAnswer);
			
		}
		prompt.validate();
		return;
	}
	
	private static void answerElementPrompt(WebElementsPrompt prompt) throws WebObjectsException {
		//System.out.println("\nMethod Call: answerElementPrompt");
		
		WebElements defaultAnswer = prompt.getAnswer();
		WebElementSource eltSrc=prompt.getOrigin().getElementSource();
		WebElements elements = eltSrc.getElements();
		WebElements we = prompt.getAnswer();
		
		WebElementsPromptAnswer wepa;
		
		defaultAnswer.clear();
		if(prompt.getUserAnswers().size() >0) {
			//we.add(prompt.getUserAnswers().get(0).getName());
			wepa = (WebElementsPromptAnswer) prompt.getUserAnswers().get(0);
			wepa.populate();
			prompt.setAnswer(wepa.getAnswer());
			prompt.validate();
			return;
		}else {
			//for (int e = 0; e < elements.size(); e++) {
			String originName = prompt.getOrigin().getName();
			if(elements.size()>0) {
				String elemName = elements.get(0).getDisplayName();
				//System.out.println("originName: " + originName + "; elemName: " + elemName);
				
				we.add(elements.get(0).getElementID());
			}

			//}
		}

	
		
		prompt.setAnswer(we);
		prompt.validate();
		return;
	}
	
	private static String buildPath(SimpleList lList){
		String lPath = "";
		for (int i =0; i< lList.size(); i++){
			WebFolder lFolder = (WebFolder)lList.item(i);
			lPath = lPath + "\\" + lFolder.getName();
		}
		return lPath;
	}
	
	public static void main(String[] args) throws ConfigurationException{
		//mUser = args[0];
		//mPassword = args[1];
		//mProjectName = args[2];
		
		Parameters params = new Parameters();
		FileBasedConfigurationBuilder<FileBasedConfiguration> builder =
		    new FileBasedConfigurationBuilder<FileBasedConfiguration>(PropertiesConfiguration.class)
		    .configure(params.properties()
		        .setFileName("application.properties"));
		gConfig = builder.getConfiguration();
		
		
		getSession();
		createInserters();
		populateTableInfo();
		populateDerivedMetricData();
		System.exit(0);
	}
	
}
