import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.configuration2.Configuration;

public class ErrorInserter {
	
	private static ErrorInserter mInstance;
	
	
	private Connection mConnection;
	private PreparedStatement mPreparedStmtRepDef;
	private Configuration gConfig;
	
	private ErrorInserter(Connection iConn, Configuration iConfig) throws SQLException{
		gConfig = iConfig;
		String lErrorTable = gConfig.getString("table.error");
		mConnection = iConn;
		
		mPreparedStmtRepDef = iConn.prepareStatement("insert into "+ lErrorTable +" (OBJ_GUID, OBJ_TYPE, ERR_TYPE) "
				+ "values (?, ?, ?)");

	}
	
	public static ErrorInserter getErrorInserter(Connection iConn, Configuration iConfig) throws SQLException{
		if(mInstance == null){
			mInstance = new ErrorInserter(iConn, iConfig);
		}
		return mInstance;
	}
	
	public void insertErrorInfo(String iRepGUID, String iErr) throws SQLException{
		
		Boolean lDoInserts = Boolean.parseBoolean(gConfig.getString("config.doerrorinserts"));
		
		if(lDoInserts) {
			mPreparedStmtRepDef.setString (1, iRepGUID);
			mPreparedStmtRepDef.setString (2, "Report");
			mPreparedStmtRepDef.setString (3, iErr);
			  // execute the preparedstatement
			mPreparedStmtRepDef.execute();
		}

		
	}
	
}
