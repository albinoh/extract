import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import org.apache.commons.configuration2.Configuration;

public class PromptAnswersAnalyser {
	
	private static PromptAnswersAnalyser mInstance;
	
	
	private Connection mConnection;
	private PreparedStatement mPreparedStmtPrAns;
	private Configuration gConfig;
	
	private PromptAnswersAnalyser(Connection iConn, Configuration iConfig) throws SQLException{
		gConfig = iConfig;
		String lPromptAnswersTable = gConfig.getString("table.promptanswers");


		mConnection = iConn;
		mPreparedStmtPrAns = iConn.prepareStatement("insert into "+lPromptAnswersTable+" (REP_GUID, PROMPT_GUID, USER_GUID, OBJ_GUID, MONTH_NUM, OBJ_COUNT, PROJ_GUID) "
				+ "values (?, ?, ?, ?, ?, ?, ?)");
	}
	
	public static PromptAnswersAnalyser getPromptAnswersAnalyser(Connection iConn, Configuration iConfig) throws SQLException{
		if(mInstance == null){
			mInstance = new PromptAnswersAnalyser(iConn, iConfig);
		}
		return mInstance;
	}
	
	public void processPromptAns(String lReportID, String lPromptID, String lProjectID) throws SQLException {
		String lPromptQuery = gConfig.getString("query.prompt");
		Hashtable<String, String> lUserNameLookup = new Hashtable<String,String>();
		Hashtable<Integer, Hashtable<String, Hashtable<String, Integer>>> lAnsTable = new Hashtable<Integer, Hashtable<String,Hashtable<String, Integer>>>();
		
		Boolean lDoInserts = Boolean.parseBoolean(gConfig.getString("config.dopromptinserts"));
		
		if(lDoInserts) {
		
			PreparedStatement st = mConnection.prepareStatement(lPromptQuery);
			ResultSet rec;
			try {
				st = mConnection.prepareStatement(lPromptQuery, ResultSet.TYPE_FORWARD_ONLY, ResultSet.CONCUR_READ_ONLY);
				st.setFetchSize(500);
				st.setString(1, lReportID);
				st.setString(2, lPromptID);
				
				rec = st.executeQuery();
				String lRetReportID = "";
				Date lDay = null;
				Integer lMonthNumber;
				String lUser;
				String lUserName;
				List<String> lAnswers;
				while (rec.next()) {
					Calendar lCalendar = Calendar.getInstance();
					lDay = rec.getDate(1);
					lCalendar.setTime(lDay);
					lMonthNumber = lCalendar.get(Calendar.YEAR)*100 + lCalendar.get(Calendar.MONTH)+1;
					lUser = rec.getString(5);

					
					String lCommaAnswers = (rec.getString(4) == null)?"":rec.getString(4);
					lAnswers = Arrays.asList(lCommaAnswers.split("\\s*,\\s*"));
					//Month->User->Ans->Count
					for(String lAns : lAnswers) {
						Hashtable<String, Hashtable<String, Integer>> lCurrMonthTable;
						Hashtable<String, Integer> lCurrUserTable;
						//Create or get the Date hashtable
						if(!lAnsTable.containsKey(lMonthNumber)) {
							lCurrMonthTable = new Hashtable<String, Hashtable<String, Integer>>();
							lAnsTable.put(lMonthNumber, lCurrMonthTable);
						}else {
							lCurrMonthTable = lAnsTable.get(lMonthNumber);
						}
						//Create or get the Date/User hashtable
						if(!lCurrMonthTable.containsKey(lUser)) {
							lCurrUserTable = new Hashtable<String, Integer>();
							lCurrMonthTable.put(lUser, lCurrUserTable);
						}else {			
							lCurrUserTable = lCurrMonthTable.get(lUser);
						}
						//Add or replace the answer count ofr a Date/user combination
						if(!lCurrUserTable.containsKey(lAns)) {
							lCurrUserTable.put(lAns, 1);
						}else {
							int lCurrValue = lCurrUserTable.get(lAns);
							lCurrUserTable.replace(lAns, ++lCurrValue);
						}
					}
		
				}
				for(Map.Entry<Integer, Hashtable<String, Hashtable<String, Integer>>> entry : lAnsTable.entrySet()) {
					Integer lInsertMonth = entry.getKey();
					Hashtable<String, Hashtable<String, Integer>> lMonthTable = entry.getValue();
					for(Map.Entry<String, Hashtable<String, Integer>> entry2 : lMonthTable.entrySet()) {
						String lPrUser = entry2.getKey();
						Hashtable<String, Integer> lUserTable = entry2.getValue();
						for(Map.Entry<String, Integer> entry3 : lUserTable.entrySet()) {
							String lObjGUID = entry3.getKey();
							Integer lCount = entry3.getValue();
							mPreparedStmtPrAns.setString(1, lReportID);
							mPreparedStmtPrAns.setString(2, lPromptID);
							mPreparedStmtPrAns.setString(3, lPrUser);
							mPreparedStmtPrAns.setString(4, lObjGUID);
							mPreparedStmtPrAns.setInt(5, lInsertMonth);
							mPreparedStmtPrAns.setInt(6, lCount);
							mPreparedStmtPrAns.setString(7, lProjectID);
							mPreparedStmtPrAns.execute();
						}	
					}
				}
				rec.close();
				st.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				st.close();
				e.printStackTrace();
			}
		}

	}
}