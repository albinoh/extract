import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.configuration2.Configuration;

public class AttributeInserter {
	
	private static AttributeInserter mInstance;
	
	
	private Connection mConnection;
	private PreparedStatement mPreparedStmtAttDef;
	private PreparedStatement mPreparedStmtAttRel;
	private Configuration gConfig;
	
	private AttributeInserter(Connection iConn, Configuration iConfig) throws SQLException{
		gConfig = iConfig;
		String lAttributeTable = gConfig.getString("table.attribute");
		String lAttributeRelateTable = gConfig.getString("table.attributerelate");
		mConnection = iConn;
		
		mPreparedStmtAttDef = iConn.prepareStatement("insert into "+lAttributeTable+" (ATT_GUID, ATT_NAME, ATT_OWNER_GUID, ATT_OWNER_NAME, "
				+ "ATT_CREATE_DATE, ATT_MODIF_DATE, PROJ_GUID) "
				+ "values (?, ?, ?, ?, ?, ?, ?)");
		mPreparedStmtAttRel = iConn.prepareStatement("insert into "+lAttributeRelateTable+" (ATT_GUID, REP_GUID, PROJ_GUID, TEMPLATE_FLAG) "
				+ "values (?, ?, ?, ?)");
		
	}
	
	public static AttributeInserter getAttributeInserter(Connection iConn, Configuration iConfig) throws SQLException{
		if(mInstance == null){
			mInstance = new AttributeInserter(iConn, iConfig);
		}
		return mInstance;
	}
	
	public void insertAttributeInfo(Boolean onlyRelate, String iAttGUID, String iAttName, String iAttOwnerGUID, String iAttOwnerName, 
			String iAttCreation, String iAttModification, String iReportGUID, String iProjectGUID, Short isPromptSource ) throws SQLException{
		
		Boolean lDoInserts = Boolean.parseBoolean(gConfig.getString("config.doattinserts"));
		Boolean lDoRelInserts = Boolean.parseBoolean(gConfig.getString("config.doattrelinserts"));
		
		if(lDoInserts) {
			if(!onlyRelate) {
				mPreparedStmtAttDef.setString (1, iAttGUID);
				mPreparedStmtAttDef.setString (2, iAttName);
				mPreparedStmtAttDef.setString (3, iAttOwnerGUID);
				mPreparedStmtAttDef.setString (4, iAttOwnerName);
				mPreparedStmtAttDef.setString (5, iAttCreation);
				mPreparedStmtAttDef.setString (6, iAttModification);
				mPreparedStmtAttDef.setString (7, iProjectGUID);
				  // execute the preparedstatement
				mPreparedStmtAttDef.execute();
			}
		}
		
		if(lDoRelInserts) {
			mPreparedStmtAttRel.setString (1, iAttGUID);
			mPreparedStmtAttRel.setString (2, iReportGUID);
			mPreparedStmtAttRel.setString (3, iProjectGUID);
			mPreparedStmtAttRel.setShort(4, isPromptSource);
			mPreparedStmtAttRel.execute();
		}
	}
	
}
