import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.commons.configuration2.Configuration;

public class ReportTableRelInserter {
	
	private static ReportTableRelInserter mInstance;
	
	
	private Connection mConnection;
	private PreparedStatement mPreparedStmtRepDef;
	private Configuration gConfig;
	
	private ReportTableRelInserter(Connection iConn, Configuration iConfig) throws SQLException{
		gConfig = iConfig;
		String lReportTable = gConfig.getString("table.reporttablerel");
		mConnection = iConn;
		mPreparedStmtRepDef = iConn.prepareStatement("insert into "+ lReportTable +" (TAB_ID, TAB_GUID, TAB_NAME,"
				+ "REP_ID, REP_GUID, REP_NAME, REPO_GUID, PROJ_ID, PROJ_GUID) "
				+ "values (?, ?, ?, ?, ?, ?, ?, ?, ?)");

	}
	
	
	public static ReportTableRelInserter getReportTableRelInserter(Connection iConn, Configuration iConfig) throws SQLException{
		if(mInstance == null){
			mInstance = new ReportTableRelInserter(iConn, iConfig);
		}
		return mInstance;
	}
	
	
	public void insertReportTableRelInfo(String iTabID, String iTabGUID, String iTabName, 
			String iRepID, String iRepGUID, String iRepName, 
			String iRepoGUID, String iProjID, String iProjGUID) throws SQLException{
		Boolean lDoInserts = Boolean.parseBoolean(gConfig.getString("config.doreptabinserts"));
		
		if(lDoInserts) {
			mPreparedStmtRepDef.setString (1, iTabID);
			mPreparedStmtRepDef.setString (2, iTabGUID);
			mPreparedStmtRepDef.setString (3, iTabName);
			mPreparedStmtRepDef.setString (4, iRepID);
			mPreparedStmtRepDef.setString (5, iRepGUID);
			mPreparedStmtRepDef.setString (6, iRepName);
			mPreparedStmtRepDef.setString (7, iRepoGUID);
			mPreparedStmtRepDef.setString (8, iProjID);
			mPreparedStmtRepDef.setString (9, iProjGUID);
			  // execute the preparedstatement
			mPreparedStmtRepDef.execute();
		}
		
	}
	
}
